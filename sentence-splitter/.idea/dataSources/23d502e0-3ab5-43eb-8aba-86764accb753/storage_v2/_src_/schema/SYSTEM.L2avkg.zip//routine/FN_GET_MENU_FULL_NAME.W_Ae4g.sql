create FUNCTION "FN_GET_MENU_FULL_NAME" (
    P_MENU_ID IN VARCHAR2
) RETURN VARCHAR2 IS
/******************************************************************************
   NAME:       FN_GET_MENU_FULL_NAME
   PURPOSE:    메뉴ID에 해당하는 풀 메뉴 이름을 리턴하는 함수
   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        2014-04-29          1. Created this function.
   NOTES:
   Automatically available Auto Replace Keywords:
      Object Name:     FN_GET_MENU_FULL_NAME
      Sysdate:         2014-04-29
      Date and Time:   2014-04-29, 오후 3:35:06, and 2014-04-29 오후 3:35:06
      Username:         (set in TOAD Options, Procedure Editor)
      Table Name:       (set in the "New PL/SQL Object" dialog)
******************************************************************************/
V_FULL_MENU_NAME  VARCHAR2(1000);
BEGIN
    DECLARE
        CURSOR C1 IS 
            SELECT *
              FROM AP_MENU
             START WITH MENU_ID = P_MENU_ID
             CONNECT BY PRIOR PARENT_MENU_ID = MENU_ID
             ORDER BY DEPTH ASC;

    BEGIN
        V_FULL_MENU_NAME := '';
        FOR L1 IN C1 LOOP
            V_FULL_MENU_NAME := V_FULL_MENU_NAME || CASE WHEN V_FULL_MENU_NAME IS NOT NULL THEN ' > ' ELSE '' END || L1.MENU_NAME; 
        END LOOP;       

    END;
    RETURN V_FULL_MENU_NAME;
END FN_GET_MENU_FULL_NAME;

/

